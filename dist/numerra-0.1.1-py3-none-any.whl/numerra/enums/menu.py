from enum import Enum

class Menu(Enum):
  ADD = 1
  SUB = 2
  MUL = 3
  DIV = 4
  HISTORY = 5
  CLEAR = 6
  EXIT = 7